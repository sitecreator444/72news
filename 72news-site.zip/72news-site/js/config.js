// Te dwie wartości są PUBLICZNE z założenia (Supabase: Project Settings > API).
// Bezpieczeństwo zapewniają reguły RLS z sql/schema.sql. NIGDY nie wpisuj tu klucza "service_role".
window.CFG={SUPABASE_URL:"https://TWOJ-PROJEKT.supabase.co",SUPABASE_ANON_KEY:"TWOJ_PUBLICZNY_ANON_KEY"};
