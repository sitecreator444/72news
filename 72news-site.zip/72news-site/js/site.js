(()=>{
const sb=supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY);
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const yt=u=>{const m=String(u||"").match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([\w-]{11})/);return m&&m[1]};
const SEL="*,categories(name,slug)",page=document.body.dataset.page,path=location.pathname;
$('#hdr').outerHTML=`<header class="top"><div class="wrap"><a class="brand" href="/"><img src="/img/logo-sm.jpg" alt="72 NEWS"></a><button class="burger" aria-label="Menu">☰</button><nav>${[["/","Strona główna"],["/przepisy","Przepisy"],["/#wideo","Wywiady"]].map(([h,t])=>`<a href="${h}" class="${h===path?'on':''}">${t}</a>`).join('')}</nav></div></header>`;
$('.burger').onclick=()=>$('nav').classList.toggle('open');
$('#ftr').outerHTML=`<footer><div class="wrap"><div><b>72 NEWS</b><p>Smaki, historie i przepisy<br>prosto z naszych wywiadów.</p></div><div><b>Na skróty</b><p><a href="/przepisy">Wszystkie przepisy</a><br><a href="/#wideo">Najnowsze wideo</a><br><a href="/admin/">Panel redakcji</a></p></div><div>© ${new Date().getFullYear()} 72 NEWS</div></div></footer>`;
const card=r=>`<a class="card" href="/przepisy/${esc(r.slug)}"><div class="ph">${r.image_url?`<img loading="lazy" src="${esc(r.image_url)}" alt="${esc(r.title)}">`:`<img class="fb" src="/img/logo.jpg" alt="">`}${r.categories?`<span class="tag">${esc(r.categories.name)}</span>`:''}</div><div class="cb"><h3>${esc(r.title)}</h3><p>${esc(r.description)}</p><div class="meta">⏱ ${esc(r.prep_time)} · 🍽 ${esc(r.servings)} porcji · ${esc(r.difficulty)}</div></div></a>`;
const all=async()=>{const {data,error}=await sb.from('recipes').select(SEL).eq('published',true).order('created_at',{ascending:false});if(error)console.error(error);return error?null:data};
const ERR='<p class="empty">Nie udało się wczytać przepisów. Spróbuj ponownie później.</p>';
if(page==='home'){
 all().then(rs=>{
  $('#featured').innerHTML=!rs?ERR:rs.length?rs.slice(0,6).map(card).join(''):'<p class="empty">Przepisy pojawią się wkrótce.</p>';
  const v=(rs||[]).filter(r=>yt(r.youtube_url)).slice(0,3);
  $('#videos').innerHTML=v.length?v.map(r=>`<a class="card" href="/przepisy/${esc(r.slug)}"><div class="ph"><img loading="lazy" src="https://i.ytimg.com/vi/${yt(r.youtube_url)}/hqdefault.jpg" alt=""><span class="play">▶</span></div><div class="cb"><h3>${esc(r.title)}</h3><p>${r.author?'Gość: '+esc(r.author):''}</p></div></a>`).join(''):'<p class="empty">Materiały wideo z wywiadów pojawią się tutaj wkrótce.</p>';
 });
 const v=$('.vid video');if(v&&matchMedia('(prefers-reduced-motion:reduce)').matches){v.removeAttribute('autoplay');v.pause()}
}
if(page==='list'){
 let rs=[],cat='';const inp=$('#q');inp.value=new URLSearchParams(location.search).get('q')||'';
 const draw=()=>{const q=inp.value.toLowerCase().trim();const f=rs.filter(r=>(!cat||r.categories?.slug===cat)&&(!q||[r.title,r.description,r.author,r.categories?.name,(r.ingredients||[]).map(i=>i.item).join(' ')].join(' ').toLowerCase().includes(q)));$('#list').innerHTML=f.length?f.map(card).join(''):'<p class="empty">Brak przepisów spełniających kryteria.</p>'};
 all().then(d=>{if(!d){$('#list').innerHTML=ERR;return}rs=d;const cs=[...new Map(rs.filter(r=>r.categories).map(r=>[r.categories.slug,r.categories.name]))];$('#chips').innerHTML=[['','Wszystkie'],...cs].map(([s,n])=>`<button class="chip${s?'':' on'}" data-c="${esc(s)}">${esc(n)}</button>`).join('');draw()});
 $('#chips').onclick=e=>{const b=e.target.closest('.chip');if(!b)return;cat=b.dataset.c;document.querySelectorAll('.chip').forEach(c=>c.classList.toggle('on',c===b));draw()};
 inp.oninput=draw;
}
if(page==='recipe'){
 const slug=decodeURIComponent(path.split('/').filter(Boolean).pop()||'');
 sb.from('recipes').select(SEL).eq('slug',slug).eq('published',true).maybeSingle().then(({data:r})=>{
  const el=$('#recipe');
  if(!r){el.innerHTML='<div class="empty">Nie znaleziono przepisu. <a href="/przepisy"><u>Wróć do listy</u></a></div>';return}
  document.title=`${r.title} – przepis | 72 NEWS`;
  const set=(s,v)=>{const m=$(s);m&&m.setAttribute('content',v)};
  set('meta[name=description]',r.description||r.title);set('meta[property="og:title"]',r.title);set('meta[property="og:description"]',r.description||'');if(r.image_url)set('meta[property="og:image"]',r.image_url);
  const ld=document.createElement('script');ld.type='application/ld+json';
  ld.textContent=JSON.stringify({"@context":"https://schema.org","@type":"Recipe",name:r.title,description:r.description,image:r.image_url,author:{"@type":"Person",name:r.author||'Redakcja 72 NEWS'},recipeYield:`${r.servings} porcji`,recipeCategory:r.categories?.name,recipeIngredient:(r.ingredients||[]).map(i=>`${i.amount} ${i.item}`.trim()),recipeInstructions:(r.steps||[]).map(t=>({"@type":"HowToStep",text:t}))});
  document.head.append(ld);
  const id=yt(r.youtube_url),link=/^https?:\/\//.test(r.interview_url||'')?r.interview_url:null;
  el.innerHTML=`<p><a href="/przepisy" class="noprint">← Wszystkie przepisy</a></p><h1 class="metal">${esc(r.title)}</h1><p class="sub">${esc(r.description)}</p>
  <div class="facts">${[['Czas',r.prep_time],['Porcje',r.servings],['Trudność',r.difficulty],['Kategoria',r.categories?.name],['Autor / gość',r.author]].filter(x=>x[1]).map(([k,v])=>`<div class="fact"><small>${k}</small>${esc(v)}</div>`).join('')}</div>
  <div class="rimg"><img src="${esc(r.image_url||'/img/logo.jpg')}" alt="${esc(r.title)}"></div>
  <button class="btn noprint" onclick="print()">🖨 Drukuj przepis</button>
  <div class="cols"><aside><h2>Składniki</h2><ul class="ing">${(r.ingredients||[]).map(i=>`<li><b>${esc(i.amount)}</b>${esc(i.item)}</li>`).join('')}</ul></aside><div><h2>Przygotowanie</h2><ol class="steps">${(r.steps||[]).map(s=>`<li>${esc(s)}</li>`).join('')}</ol></div></div>
  <section class="noprint"><h2 class="sec">Wywiad</h2>${id?`<div class="player" data-id="${id}"><img src="https://i.ytimg.com/vi/${id}/hqdefault.jpg" alt="Miniatura wywiadu"><button aria-label="Odtwórz">▶</button></div>`:'<p class="empty">Film z wywiadu zostanie dodany wkrótce.</p>'}${link?`<p><a class="btn" href="${esc(link)}" target="_blank" rel="noopener">Zobacz pełny wywiad</a></p>`:''}</section>`;
  const p=$('.player');if(p)p.onclick=()=>{p.innerHTML=`<iframe src="https://www.youtube-nocookie.com/embed/${p.dataset.id}?autoplay=1" allow="autoplay;encrypted-media;picture-in-picture" allowfullscreen title="Wywiad"></iframe>`};
 });
}
})();
