-- Uruchom w Supabase: SQL Editor > New query > Run
create table categories(id uuid primary key default gen_random_uuid(),name text not null unique,slug text not null unique);
create table recipes(
 id uuid primary key default gen_random_uuid(),
 slug text not null unique, title text not null, description text, image_url text,
 ingredients jsonb not null default '[]', steps jsonb not null default '[]',
 prep_time text, servings int, difficulty text check(difficulty in ('Łatwy','Średni','Trudny')),
 category_id uuid references categories(id) on delete set null,
 author text, youtube_url text, interview_url text,
 published boolean not null default false, created_at timestamptz not null default now());
create table admins(user_id uuid primary key references auth.users(id) on delete cascade);
create function is_admin() returns boolean language sql security definer stable set search_path=public as
$$ select exists(select 1 from admins where user_id=auth.uid()) $$;

alter table categories enable row level security;
alter table recipes enable row level security;
alter table admins enable row level security; -- brak polityk = brak dostępu z przeglądarki
create policy "cat_read" on categories for select using(true);
create policy "cat_admin" on categories for all using(is_admin()) with check(is_admin());
create policy "rec_read" on recipes for select using(published or is_admin());
create policy "rec_admin" on recipes for all using(is_admin()) with check(is_admin());

insert into storage.buckets(id,name,public) values('recipe-images','recipe-images',true) on conflict do nothing;
create policy "img_read" on storage.objects for select using(bucket_id='recipe-images');
create policy "img_admin" on storage.objects for all using(bucket_id='recipe-images' and is_admin()) with check(bucket_id='recipe-images' and is_admin());

-- Dane startowe: 2 kategorie i dokładnie 2 przepisy (zdjęcia dodasz w panelu)
insert into categories(name,slug) values('Dania główne','dania-glowne'),('Desery','desery');
insert into recipes(slug,title,description,ingredients,steps,prep_time,servings,difficulty,category_id,author,published) values
('pierogi-ruskie','Pierogi ruskie','Klasyczne pierogi z ziemniakami, twarogiem i smażoną cebulką.',
'[{"amount":"500 g","item":"mąka pszenna"},{"amount":"250 ml","item":"ciepła woda"},{"amount":"2 łyżki","item":"oleju"},{"amount":"1 łyżeczka","item":"soli"},{"amount":"600 g","item":"ziemniaków"},{"amount":"300 g","item":"twarogu półtłustego"},{"amount":"2 szt.","item":"cebuli"},{"amount":"2 łyżki","item":"masła"},{"amount":"do smaku","item":"sól i pieprz"}]',
'["Wymieszaj mąkę z solą, dodaj olej i ciepłą wodę, zagnieć gładkie ciasto i odstaw na 30 minut pod przykryciem.","Ugotuj obrane ziemniaki w osolonej wodzie, odcedź i dokładnie rozgnieć.","Posiekaną cebulę zeszklij na maśle, połowę dodaj do ziemniaków.","Dodaj twaróg, sól i pieprz, wymieszaj na jednolity farsz.","Rozwałkuj ciasto, wytnij kółka, nałóż farsz i sklej brzegi.","Gotuj pierogi w osolonej wodzie 3–4 minuty od wypłynięcia. Podawaj z resztą cebulki."]',
'90 min',6,'Średni',(select id from categories where slug='dania-glowne'),'Redakcja 72 NEWS',true),
('szarlotka-na-kruchym-ciescie','Szarlotka na kruchym cieście','Domowa szarlotka z kwaśnymi jabłkami i cynamonem pod kruszonką.',
'[{"amount":"400 g","item":"mąka pszenna"},{"amount":"200 g","item":"zimne masło"},{"amount":"100 g","item":"cukier puder"},{"amount":"3 szt.","item":"żółtka"},{"amount":"1 łyżeczka","item":"proszek do pieczenia"},{"amount":"1,5 kg","item":"kwaśnych jabłek"},{"amount":"3 łyżki","item":"cukru"},{"amount":"1 łyżeczka","item":"cynamonu"}]',
'["Szybko zagnieć mąkę, masło, cukier puder, żółtka i proszek na kruche ciasto. Podziel na dwie części i schłodź 30 minut.","Jabłka obierz, zetrzyj na grubych oczkach, wymieszaj z cukrem i cynamonem, odcedź nadmiar soku.","Rozgrzej piekarnik do 180°C. Jedną część ciasta zetrzyj na tarce na dno formy.","Wyłóż jabłka, a na wierzch zetrzyj drugą część ciasta.","Piecz 50–60 minut do złotego koloru. Przestudź przed pokrojeniem."]',
'100 min',10,'Łatwy',(select id from categories where slug='desery'),'Redakcja 72 NEWS',true);
-- Po utworzeniu konta admina (Authentication > Users > Add user) wykonaj:
-- insert into admins(user_id) select id from auth.users where email='TWOJ@EMAIL';
