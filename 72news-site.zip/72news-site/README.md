# 72 NEWS – portal kulinarny

Statyczny frontend + Supabase (baza, logowanie, zdjęcia). Bez budowania i bez Node.

## Uruchomienie (ok. 15 minut)
1. Załóż projekt na supabase.com. W SQL Editor wklej i uruchom `sql/schema.sql` (tabele, zabezpieczenia RLS, bucket na zdjęcia, 2 przepisy startowe).
2. Authentication > Users > Add user: utwórz konto administratora (e-mail + hasło). Potem w SQL Editor:
   `insert into admins(user_id) select id from auth.users where email='TWOJ@EMAIL';`
3. Authentication > Sign In / Providers: wyłącz publiczne rejestracje ("Allow new users to sign up").
4. W `js/config.js` wpisz Project URL i klucz **anon** (Project Settings > API). Klucza service_role nigdy tu nie wstawiaj.
5. Wgraj cały folder na Netlify lub Cloudflare Pages (przeciągnij folder; plik `_redirects` daje adresy /przepisy/nazwa-przepisu).
6. Wejdź na `/admin/`, zaloguj się i dodaj zdjęcia do dwóch przepisów.

## Bezpieczeństwo
Klucz anon jest publiczny z założenia. Dostęp do zapisu mają wyłącznie konta z tabeli `admins` (reguły RLS w bazie, nie w kodzie strony). Niepublikowane przepisy widzi tylko administrator.
