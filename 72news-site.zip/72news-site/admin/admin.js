const sb=supabase.createClient(CFG.SUPABASE_URL,CFG.SUPABASE_ANON_KEY);
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const slug=s=>s.toLowerCase().replace(/ł/g,'l').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
let cats=[],recs=[];
const toast=(m,e)=>{const t=$('#toast');t.textContent=m;t.className='show'+(e?' err':'');setTimeout(()=>t.className='',3200)};
const showLogin=()=>{$('#app').hidden=true;$('#login').hidden=false};
async function enter(){
 const {data:ok}=await sb.rpc('is_admin');
 if(!ok){await sb.auth.signOut();showLogin();return toast('To konto nie ma uprawnień administratora',1)}
 $('#login').hidden=true;$('#app').hidden=false;await load();view('list');
}
async function load(){
 const [c,r]=await Promise.all([sb.from('categories').select('*').order('name'),sb.from('recipes').select('*').order('created_at',{ascending:false})]);
 cats=c.data||[];recs=r.data||[];
}
$('#lf').onsubmit=async e=>{e.preventDefault();const {error}=await sb.auth.signInWithPassword({email:$('#em').value,password:$('#pw').value});error?toast('Błędny e-mail lub hasło',1):enter()};
$('#out').onclick=async()=>{await sb.auth.signOut();showLogin()};
function view(v,r){document.querySelectorAll('.tabs button').forEach(b=>b.classList.toggle('on',b.dataset.v===(v==='form'?'list':v)));({list:vList,cats:vCats,form:()=>vForm(r)})[v]()}
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>view(b.dataset.v));
const done=async(error,msg)=>{if(error)return toast(error.message,1);await load();toast(msg||'Zapisano');return true};

function vList(){
 $('#main').innerHTML=`<div class="bar"><h2>Przepisy (${recs.length})</h2><button class="btn" data-a="n">+ Nowy przepis</button></div><div style="overflow-x:auto"><table class="tbl"><tr><th>Nazwa<th>Kategoria<th>Status<th></tr>${recs.map(r=>`<tr><td>${esc(r.title)}<td>${esc(cats.find(c=>c.id===r.category_id)?.name||'—')}<td><span class="st ${r.published?'on':''}">${r.published?'Opublikowany':'Ukryty'}</span><td class="act"><button data-a="e" data-id="${r.id}">Edytuj</button><button data-a="p" data-id="${r.id}">${r.published?'Ukryj':'Publikuj'}</button><button data-a="d" data-id="${r.id}">Usuń</button></tr>`).join('')}</table></div>`;
}
function vCats(){
 $('#main').innerHTML=`<div class="bar"><h2>Kategorie</h2></div><form id="cf" class="bar" style="max-width:480px"><input id="cn" placeholder="Nazwa nowej kategorii" required><button class="btn">Dodaj</button></form><table class="tbl">${cats.map(c=>`<tr><td><input value="${esc(c.name)}"><td class="act"><button data-a="cs" data-id="${c.id}">Zapisz</button><button data-a="cd" data-id="${c.id}">Usuń</button></tr>`).join('')}</table>`;
 $('#cf').onsubmit=async e=>{e.preventDefault();const n=$('#cn').value.trim();if(await done((await sb.from('categories').insert({name:n,slug:slug(n)})).error,'Dodano kategorię'))vCats()};
}
$('#main').addEventListener('click',async e=>{
 const b=e.target.closest('[data-a]');if(!b)return;const a=b.dataset.a,r=recs.find(x=>x.id===b.dataset.id);
 if(a==='n')view('form',{});
 if(a==='e')view('form',r);
 if(a==='p'&&await done((await sb.from('recipes').update({published:!r.published}).eq('id',r.id)).error))vList();
 if(a==='d'&&confirm(`Usunąć przepis „${r.title}”? Tej operacji nie można cofnąć.`)&&await done((await sb.from('recipes').delete().eq('id',r.id)).error,'Usunięto'))vList();
 if(a==='cs'){const n=b.closest('tr').querySelector('input').value.trim();if(await done((await sb.from('categories').update({name:n,slug:slug(n)}).eq('id',b.dataset.id)).error))vCats()}
 if(a==='cd'&&confirm('Usunąć kategorię? Przepisy zostaną bez kategorii.')&&await done((await sb.from('categories').delete().eq('id',b.dataset.id)).error,'Usunięto'))vCats();
});

function vForm(r){
 const v=k=>esc(r[k]);
 $('#main').innerHTML=`<form id="rf" class="form"><h2>${r.id?'Edytuj':'Nowy'} przepis</h2>
 <label>Nazwa<input name="title" required value="${v('title')}"></label>
 <label>Adres w URL (generuje się sam)<input name="slug" required value="${v('slug')}"></label>
 <label>Kategoria<select name="category_id"><option value="">—</option>${cats.map(c=>`<option value="${c.id}" ${c.id===r.category_id?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label>
 <label>Krótki opis<textarea name="description" rows="2">${v('description')}</textarea></label>
 <div class="g3"><label>Czas przygotowania<input name="prep_time" placeholder="45 min" value="${v('prep_time')}"></label><label>Liczba porcji<input name="servings" type="number" min="1" value="${v('servings')}"></label><label>Poziom trudności<select name="difficulty">${['Łatwy','Średni','Trudny'].map(d=>`<option ${d===(r.difficulty||'Średni')?'selected':''}>${d}</option>`).join('')}</select></label></div>
 <label>Autor przepisu / gość wywiadu<input name="author" value="${v('author')}"></label>
 <label>Zdjęcie potrawy<input type="file" id="fi" accept="image/*"></label>${r.image_url?`<img id="pv" class="pv" src="${esc(r.image_url)}" alt="">`:''}
 <label>Składniki — jeden w linii w formacie: ilość | składnik<textarea name="ingredients" rows="8" placeholder="500 g | mąka pszenna">${esc((r.ingredients||[]).map(i=>`${i.amount} | ${i.item}`).join('\n'))}</textarea></label>
 <label>Kroki przygotowania — jeden krok w linii<textarea name="steps" rows="8">${esc((r.steps||[]).join('\n'))}</textarea></label>
 <label>Link do filmu YouTube<input name="youtube_url" placeholder="https://www.youtube.com/watch?v=..." value="${v('youtube_url')}"></label>
 <label>Link do pełnego wywiadu<input name="interview_url" placeholder="https://..." value="${v('interview_url')}"></label>
 <label class="chk"><input type="checkbox" name="published" ${r.published?'checked':''}> Opublikowany (widoczny na stronie)</label>
 <div class="bar" style="justify-content:flex-start"><button class="btn">Zapisz</button><button type="button" class="ghost" id="cl">Anuluj</button></div></form>`;
 const f0=$('#rf');if(!r.id)f0.title.oninput=()=>f0.slug.value=slug(f0.title.value);
 $('#cl').onclick=()=>view('list');
 f0.onsubmit=async e=>{
  e.preventDefault();const f=new FormData(f0);let image_url=r.image_url||null;const file=$('#fi').files[0];
  if(file){const p=`${crypto.randomUUID()}.${(file.name.split('.').pop()||'jpg').toLowerCase()}`;const u=await sb.storage.from('recipe-images').upload(p,file,{cacheControl:'31536000'});if(u.error)return toast(u.error.message,1);image_url=sb.storage.from('recipe-images').getPublicUrl(p).data.publicUrl}
  const lines=k=>f.get(k).split('\n').map(s=>s.trim()).filter(Boolean);
  const row={title:f.get('title').trim(),slug:slug(f.get('slug')),category_id:f.get('category_id')||null,description:f.get('description'),prep_time:f.get('prep_time'),servings:+f.get('servings')||null,difficulty:f.get('difficulty'),author:f.get('author'),image_url,
   ingredients:lines('ingredients').map(l=>{const [a,...i]=l.split('|');return i.length?{amount:a.trim(),item:i.join('|').trim()}:{amount:'',item:l}}),steps:lines('steps'),
   youtube_url:f.get('youtube_url')||null,interview_url:f.get('interview_url')||null,published:f.has('published')};
  const q=r.id?sb.from('recipes').update(row).eq('id',r.id):sb.from('recipes').insert(row);
  if(await done((await q).error))view('list');
 };
}
sb.auth.getSession().then(({data:{session}})=>session?enter():showLogin());
